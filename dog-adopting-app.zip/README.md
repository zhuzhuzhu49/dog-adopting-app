# Doglist

> This is the first homework for course CS175 submmited by JuntongPeng

## 2021-10-23
1. Basic features.
2. Dogs' detailed pages include their ages and slogans. *(Ages are generated randomly and slogans are all the same except for a number, which means the ages will be different if there is an another launch)*
3. Include 10 different dogs as I have only downloaded 10 images.
4. demo:

  <img src="https://user-images.githubusercontent.com/41589148/138560778-7fefc728-7c69-40c2-be8a-26f77fb11f0e.jpg" width="100px">  <img src="https://user-images.githubusercontent.com/41589148/138560918-f7fbea9a-31b7-40f9-a5e9-d7e3952c6c24.jpg" width="100px">
  
